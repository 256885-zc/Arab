import 'package:flutter/material.dart';
import 'video_player_screen.dart';

class HomeScreen extends StatelessWidget {
  final List<Map<String, String>> movies = [
    {'title': 'Movie 1', 'url': 'https://www.example.com/video1.mp4'},
    {'title': 'Movie 2', 'url': 'https://www.example.com/video2.mp4'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('CloudStream Prototype')),
      body: ListView.builder(
        itemCount: movies.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(movies[index]['title']!),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => VideoPlayerScreen(videoUrl: movies[index]['url']!),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
